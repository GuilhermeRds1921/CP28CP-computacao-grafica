import numpy as np
from scipy.spatial import Delaunay
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import csv
import sys

def read_points_from_csv(file_path):
    # Lê os pontos a partir de um arquivo CSV
    points = []
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            points.append([float(row[0]), float(row[1])])
    return np.array(points)

def delaunay_triangulation(points):
    # Realiza a triangulação de Delaunay
    tri = Delaunay(points)
    return tri

def create_svg(triangles, points, filename="triangulation.svg"):
    # Cria um gráfico usando matplotlib
    fig, ax = plt.subplots()
    
    # Plota os triângulos
    for simplex in triangles.simplices:
        pts = points[simplex]
        triangle = patches.Polygon(pts, closed=True, edgecolor='black', facecolor='none')
        ax.add_patch(triangle)
    
    # Plota os pontos
    ax.plot(points[:, 0], points[:, 1], 'ro')  # Pontos em vermelho
    
    # Ajusta o gráfico
    ax.set_aspect('equal')
    ax.set_xlim(points[:, 0].min() - 10, points[:, 0].max() + 10)
    ax.set_ylim(points[:, 1].min() - 10, points[:, 1].max() + 10)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    
    # Salva o gráfico como SVG
    plt.savefig(filename, format='svg')
    plt.close()

def main():
    # Verifica se o caminho do arquivo foi fornecido
    if len(sys.argv) != 2:
        print("Uso: python script.py <arquivo.csv>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    # Lê os pontos do arquivo CSV
    points = read_points_from_csv(file_path)
    
    # Obtém a triangulação de Delaunay
    tri = delaunay_triangulation(points)
    
    # Cria e salva o SVG com os triângulos e pontos
    create_svg(tri, points)

if __name__ == "__main__":
    main()
